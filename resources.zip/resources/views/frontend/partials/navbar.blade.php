<header class="header">
    <div class="container">
        <div class="headerMain">
            <a href="/" class="headerLogo">
                <img src="{{$site_info->logo}}" alt="{{$site_info->title}}">
                <h2 class="logotitle">{{$site_info->title}}</h2>
            </a>
        </div>
    </div>
</header>
