<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>

<head>
    <link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>
    <div style="position:absolute;top:1.10in;left:2.46in;width:1.78in;line-height:0.68in;"><span
            style="font-style:normal;font-weight:bold;font-size:29pt;font-family:FiraSans-Bold;color:#e01b84">PET
            BOX</span><span
            style="font-style:normal;font-weight:bold;font-size:29pt;font-family:FiraSans-Bold;color:#e01b84">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:1.70in;left:2.46in;width:2.59in;line-height:0.22in;"><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">Panthapath,
            Dhaka - 1205, Bangladesh</span><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">
        </span><br /><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">petboxbd@gmail.com</span><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:2.22in;left:2.46in;width:1.29in;line-height:0.19in;"><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:TimesNewRomanPSMT;color:#000000">(+88)
            016 7557 1016</span><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:TimesNewRomanPSMT;color:#000000">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:2.52in;left:1.35in;width:0.94in;line-height:0.41in;"><span
            style="font-style:normal;font-weight:bold;font-size:17pt;font-family:FiraSans-Bold;color:#283592">Invoice</span><span
            style="font-style:normal;font-weight:bold;font-size:17pt;font-family:FiraSans-Bold;color:#283592">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:2.63in;left:6.88in;width:1.02in;line-height:0.27in;"><span
            style="font-style:normal;font-weight:bold;font-size:11pt;font-family:FiraSans-Bold;color:#434343">Invoice No
            #</span><span
            style="font-style:normal;font-weight:bold;font-size:11pt;font-family:FiraSans-Bold;color:#434343">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:2.90in;left:1.35in;width:1.78in;line-height:0.23in;"><span
            style="font-style:normal;font-weight:bold;font-size:10pt;font-family:FiraSans-Bold;color:#e01b84">Saturday,
            January 21, 2023</span><span
            style="font-style:normal;font-weight:bold;font-size:10pt;font-family:FiraSans-Bold;color:#e01b84">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:2.90in;left:7.47in;width:0.42in;line-height:0.22in;"><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">#0001</span><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:3.23in;left:1.35in;width:0.90in;line-height:0.27in;"><span
            style="font-style:normal;font-weight:bold;font-size:11pt;font-family:FiraSans-Bold;color:#434343">Invoice
            for</span><span
            style="font-style:normal;font-weight:bold;font-size:11pt;font-family:FiraSans-Bold;color:#434343">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:3.23in;left:6.74in;width:1.17in;line-height:0.27in;"><span
            style="font-style:normal;font-weight:bold;font-size:11pt;font-family:FiraSans-Bold;color:#434343">Payment
            Type</span><span
            style="font-style:normal;font-weight:bold;font-size:11pt;font-family:FiraSans-Bold;color:#434343">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:3.51in;left:1.35in;width:0.43in;line-height:0.22in;"><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">Name</span><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:3.51in;left:2.46in;width:1.21in;line-height:0.22in;"><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">Fairuz
            Anika Shifa</span><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:3.51in;left:7.58in;width:0.32in;line-height:0.22in;"><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">COD</span><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:3.78in;left:1.35in;width:0.49in;line-height:0.22in;"><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">Mobile</span><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:3.85in;left:2.46in;width:1.29in;line-height:0.19in;"><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:TimesNewRomanPSMT;color:#000000">(+88)
            016 7557 1016</span><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:TimesNewRomanPSMT;color:#000000">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:3.77in;left:6.78in;width:1.12in;line-height:0.28in;"><span
            style="font-style:normal;font-weight:bold;font-size:11pt;font-family:FiraSans-Bold;color:#434343">Total
            Amount</span><span
            style="font-style:normal;font-weight:bold;font-size:11pt;font-family:FiraSans-Bold;color:#434343">
        </span><br />
        <DIV style="position:relative; left:0.51in;"><span
                style="font-style:normal;font-weight:normal;font-size:11pt;font-family:Vrinda;color:#e01b84">৳</span><span
                style="font-style:normal;font-weight:bold;font-size:11pt;font-family:FiraSans-Bold;color:#e01b84">95.00</span><span
                style="font-style:normal;font-weight:bold;font-size:11pt;font-family:FiraSans-Bold;color:#e01b84">
            </span><br /></SPAN></DIV>
    </div>
    <div style="position:absolute;top:4.08in;left:1.35in;width:0.58in;line-height:0.22in;"><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">Address</span><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:4.12in;left:2.46in;width:2.76in;line-height:0.20in;"><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">60,
            West Rajabazar, Sher-E-Bangla Nagar,</span><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">
        </span><br /><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">Tejgaon,
            Dhaka - 1215, Bangladesh</span><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:4.81in;left:1.35in;width:0.98in;line-height:0.27in;"><span
            style="font-style:normal;font-weight:bold;font-size:11pt;font-family:FiraSans-Bold;color:#2a3990">Description</span><span
            style="font-style:normal;font-weight:bold;font-size:11pt;font-family:FiraSans-Bold;color:#2a3990">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:4.81in;left:5.19in;width:0.32in;line-height:0.27in;"><span
            style="font-style:normal;font-weight:bold;font-size:11pt;font-family:FiraSans-Bold;color:#2a3990">Qty</span><span
            style="font-style:normal;font-weight:bold;font-size:11pt;font-family:FiraSans-Bold;color:#2a3990">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:4.81in;left:5.88in;width:0.83in;line-height:0.27in;"><span
            style="font-style:normal;font-weight:bold;font-size:11pt;font-family:FiraSans-Bold;color:#2a3990">Unit
            price</span><span
            style="font-style:normal;font-weight:bold;font-size:11pt;font-family:FiraSans-Bold;color:#2a3990">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:4.81in;left:7.00in;width:0.89in;line-height:0.27in;"><span
            style="font-style:normal;font-weight:bold;font-size:11pt;font-family:FiraSans-Bold;color:#2a3990">Total
            price</span><span
            style="font-style:normal;font-weight:bold;font-size:11pt;font-family:FiraSans-Bold;color:#2a3990">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:5.19in;left:1.35in;width:0.52in;line-height:0.22in;"><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">Item
            #1</span><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:5.23in;left:5.40in;width:0.11in;line-height:0.22in;"><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">2</span><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:5.21in;left:6.29in;width:0.20in;line-height:0.20in;"><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:Vrinda;color:#000000">৳</span><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:Vrinda;color:#000000"></span><br /></SPAN>
    </div>
    <div style="position:absolute;top:5.21in;left:6.39in;width:0.31in;line-height:0.22in;"><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">5.00</span><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:5.19in;left:7.41in;width:0.20in;line-height:0.20in;"><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:Vrinda;color:#000000">৳</span><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:Vrinda;color:#000000"></span><br /></SPAN>
    </div>
    <div style="position:absolute;top:5.20in;left:7.51in;width:0.38in;line-height:0.22in;"><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">10.00</span><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:5.49in;left:1.35in;width:0.53in;line-height:0.22in;"><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">Item
            #2</span><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:5.53in;left:5.39in;width:0.11in;line-height:0.22in;"><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">5</span><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:5.50in;left:6.29in;width:0.20in;line-height:0.20in;"><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:Vrinda;color:#000000">৳</span><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:Vrinda;color:#000000"></span><br /></SPAN>
    </div>
    <div style="position:absolute;top:5.51in;left:6.39in;width:0.31in;line-height:0.22in;"><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">2.00</span><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:5.48in;left:7.41in;width:0.20in;line-height:0.20in;"><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:Vrinda;color:#000000">৳</span><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:Vrinda;color:#000000"></span><br /></SPAN>
    </div>
    <div style="position:absolute;top:5.49in;left:7.51in;width:0.38in;line-height:0.22in;"><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">10.00</span><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:6.19in;left:1.35in;width:0.46in;line-height:0.22in;"><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">Notes:</span><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:6.19in;left:6.10in;width:0.61in;line-height:0.22in;"><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#2a3990">Subtotal</span><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#2a3990">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:6.16in;left:7.40in;width:0.20in;line-height:0.20in;"><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:Vrinda;color:#000000">৳</span><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:Vrinda;color:#000000"></span><br /></SPAN>
    </div>
    <div style="position:absolute;top:6.17in;left:7.50in;width:0.39in;line-height:0.22in;"><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">20.00</span><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:6.48in;left:5.55in;width:1.13in;line-height:0.22in;"><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#2a3990">Shipping
            Charge</span><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#2a3990">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:6.46in;left:7.39in;width:0.20in;line-height:0.20in;"><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:Vrinda;color:#000000">৳</span><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:Vrinda;color:#000000"></span><br /></SPAN>
    </div>
    <div style="position:absolute;top:6.46in;left:7.49in;width:0.40in;line-height:0.22in;"><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">80.00</span><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:6.78in;left:6.08in;width:0.63in;line-height:0.22in;"><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#2a3990">Discount</span><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#2a3990">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:6.75in;left:7.48in;width:0.20in;line-height:0.20in;"><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:Vrinda;color:#000000">৳</span><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:Vrinda;color:#000000"></span><br /></SPAN>
    </div>
    <div style="position:absolute;top:6.76in;left:7.58in;width:0.31in;line-height:0.22in;"><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">5.00</span><span
            style="font-style:normal;font-weight:normal;font-size:10pt;font-family:FiraSans-Regular;color:#000000">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:7.02in;left:7.20in;width:0.71in;line-height:0.33in;"><span
            style="font-style:normal;font-weight:normal;font-size:13pt;font-family:Vrinda;color:#e01b84">৳</span><span
            style="font-style:normal;font-weight:bold;font-size:13pt;font-family:FiraSans-Bold;color:#e01b84">95.00</span><span
            style="font-style:normal;font-weight:bold;font-size:13pt;font-family:FiraSans-Bold;color:#e01b84">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:7.61in;left:1.35in;width:1.55in;line-height:0.21in;"><span
            style="font-style:italic;font-weight:normal;font-size:10pt;font-family:FiraSans-Italic;color:#e01b84">Thanking
            You Message</span><span
            style="font-style:italic;font-weight:normal;font-size:10pt;font-family:FiraSans-Italic;color:#e01b84">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:7.61in;left:6.77in;width:1.12in;line-height:0.21in;"><span
            style="font-style:italic;font-weight:normal;font-size:10pt;font-family:FiraSans-Italic;color:#e01b84">Important
            Notes</span><span
            style="font-style:italic;font-weight:normal;font-size:10pt;font-family:FiraSans-Italic;color:#e01b84">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:7.84in;left:1.35in;width:2.43in;line-height:0.16in;"><span
            style="font-style:italic;font-weight:normal;font-size:8pt;font-family:FiraSans-Italic;color:#666666">Thank
            you for purchasing from “PET BOX&quot;. We</span><span
            style="font-style:italic;font-weight:normal;font-size:8pt;font-family:FiraSans-Italic;color:#666666">
        </span><br /><span
            style="font-style:italic;font-weight:normal;font-size:8pt;font-family:FiraSans-Italic;color:#666666">are
            really glad for choosing us &amp; happy for</span><span
            style="font-style:italic;font-weight:normal;font-size:8pt;font-family:FiraSans-Italic;color:#666666">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:8.27in;left:1.35in;width:0.61in;line-height:0.17in;"><span
            style="font-style:italic;font-weight:normal;font-size:8pt;font-family:FiraSans-Italic;color:#666666">Thank
            you.</span><span
            style="font-style:italic;font-weight:normal;font-size:8pt;font-family:FiraSans-Italic;color:#666666">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:7.84in;left:5.57in;width:2.29in;line-height:0.16in;"><span
            style="font-style:italic;font-weight:normal;font-size:8pt;font-family:FiraSans-Italic;color:#666666">Check
            &amp; match your percel with your order</span><span
            style="font-style:italic;font-weight:normal;font-size:8pt;font-family:FiraSans-Italic;color:#666666">
        </span><br /><span
            style="font-style:italic;font-weight:normal;font-size:8pt;font-family:FiraSans-Italic;color:#666666">in
            front of our Delivey Hero after receiving.</span><span
            style="font-style:italic;font-weight:normal;font-size:8pt;font-family:FiraSans-Italic;color:#666666">
        </span><br /></SPAN></div>
    <div style="position:absolute;top:8.27in;left:6.26in;width:1.62in;line-height:0.17in;"><span
            style="font-style:italic;font-weight:normal;font-size:8pt;font-family:FiraSans-Italic;color:#666666">complain
            or isuue. Thank you.</span><span
            style="font-style:italic;font-weight:normal;font-size:8pt;font-family:FiraSans-Italic;color:#666666">
        </span><br /></SPAN></div>
    <img style="position:absolute;top:0.82in;left:5.78in;width:2.09in;height:2.09in" src="ri_1.png" />
    <img style="position:absolute;top:1.17in;left:1.16in;width:1.23in;height:1.23in" src="ri_2.png" />
</body>

</html>
